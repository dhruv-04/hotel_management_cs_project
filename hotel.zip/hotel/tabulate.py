from tabulate import *
dicti = {'Name' : ['Dhruv','Rajesh'], 'Class' : ['XII B','XII C']}
for i in dicti:
    print(tabulate.tabulate(i, header=dicti.keys(), showindex='always'))
